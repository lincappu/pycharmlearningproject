# !/usr/bin/env python3
# _*_coding:utf-8_*_
# __author__：FLS

from distutils.core import setup
setup(
	name='foo',
	version='0.1',
	author='fls',
	author_email='lincappu@163.com',
	packages=[''],

)
